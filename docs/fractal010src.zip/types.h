typedef unsigned char uchar;
typedef long double real;
