#include <stdlib.h>
#include <stdio.h>
#include "types.h"
#include "fwindow.h"
#include "math.h"
#include "windows.h"

/* fractal functions */

#define BOUND 4

fractal_window *sfw;

/*int ff_newton(real x,real y) {
  register real zx,zy,zx2,zy2,r0,r1,r2;
  zx=x,zy=y;
  register int i=sfw->maxi;
  do {
    zx2=zx*zx;
    zy2=zy*zy;
    r0=zx2-zy2-1;
    if(r0*r0+4*zx2*zy2<1e-20) break;
    r2=4*(zx2+zy2);
    zx=2*zx*(r0+2*zy2)/r2,zy=2*zy*(2*zx2-r0)/r2;
  } while(--i);
  return i;
}*/

int ff_mandel3(real x,real y) {
  register real zx,zy,cx,cy,r0,r1,r2;
  int i;
  cx=zx=x,cy=zy=y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    r2=zx;
    zx=r0*r2-r1*zy+cx;
    zy=r0*zy+r1*r2+cy;
  } while(--i);
  return i;
}

int ff_julia3(real x,real y) {
  register real zx,zy,cx,cy,r0,r1,r2;
  int i;
  zx=x,zy=y;
  cx=sfw->p1x,cy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    r2=zx;
    zx=r0*r2-r1*zy+cx;
    zy=r0*zy+r1*r2+cy;
//    zx=r0*r0-r1*r1+cx;
//    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia3b(real x,real y) {
  register real zx,zy,cx,cy,r0,r1,r2;
  int i;
  cx=x,cy=y;
  zx=sfw->p1x,zy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    r2=zx;
    zx=r0*r2-r1*zy+cx;
    zy=r0*zy+r1*r2+cy;
//    zx=r0*r0-r1*r1+cx;
//    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_mandel6(real x,real y) {
  register real zx,zy,cx,cy,r0,r1,r2;
  int i;
  cx=zx=x,cy=zy=y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    r2=zx;
    zx=r0*r2-r1*zy;
    zy=r0*zy+r1*r2;
    r2=zx;
    zx=zx*zx-zy*zy+cx;
    zy=2*r2*zy+cy;
  } while(--i);
  return i;
}

int ff_julia6(real x,real y) {
  register real zx,zy,cx,cy,r0,r1,r2;
  int i;
  zx=x,zy=y;
  cx=sfw->p1x,cy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    r2=zx;
    zx=r0*r2-r1*zy;
    zy=r0*zy+r1*r2;
    r2=zx;
    zx=zx*zx-zy*zy+cx;
    zy=2*r2*zy+cy;
  } while(--i);
  return i;
}

int ff_julia6b(real x,real y) {
  register real zx,zy,cx,cy,r0,r1,r2;
  int i;
  cx=x,cy=y;
  zx=sfw->p1x,zy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    r2=zx;
    zx=r0*r2-r1*zy;
    zy=r0*zy+r1*r2;
    r2=zx;
    zx=zx*zx-zy*zy+cx;
    zy=2*r2*zy+cy;
  } while(--i);
  return i;
}

int ff_mandel4(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  zx=cx=x,zy=cy=y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia4(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  zx=x,zy=y;
  cx=sfw->p1x,cy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia4b(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=x,cy=y;
  zx=sfw->p1x,zy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_mandel16(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=zx=x,cy=zy=y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1;
    zy=2*r0*r1;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia16(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  zx=x,zy=y;
  cx=sfw->p1x,cy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1;
    zy=2*r0*r1;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia16b(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=x,cy=y;
  zx=sfw->p1x,zy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1;
    zy=2*r0*r1;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_mandel64(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=zx=x,cy=zy=y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1;
    zy=2*r0*r1;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia64(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  zx=x,zy=y;
  cx=sfw->p1x,cy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1;
    zy=2*r0*r1;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

int ff_julia64b(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=x,cy=y;
  zx=sfw->p1x,zy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    r0=r0-r1;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1;
    zy=2*r0*r1;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
    r0=zx*zx-zy*zy;
    r1=2*zx*zy;
    zx=r0*r0-r1*r1+cx;
    zy=2*r0*r1+cy;
  } while(--i);
  return i;
}

/*
int ff_mandelbrot(real x,real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=zx=x,cy=zy=y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    zy*=zx;
    zy+=zy+cy;
    zx=r0-r1+cx;
  } while(--i);
  return i;
}

int ff_juliab(real x, real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  cx=x,cy=y;
  zx=sfw->p1x,zy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    zy*=zx;
    zy+=zy+cy;
    zx=r0-r1+cx;
  } while(--i);
  return i;
}

int ff_julia(real x, real y) {
  register real zx,zy,cx,cy,r0,r1;
  int i;
  zx=x,zy=y;
  cx=sfw->p1x,cy=sfw->p1y;
  i=sfw->maxi;
  do {
    r0=zx*zx;
    r1=zy*zy;
    if(r0+r1>4) break;
    zy*=zx;
    zy+=zy+cy;
    zx=r0-r1+cx;
  } while(--i);
  return i;
}
*/
/* int2uchar functions */

uchar i2u_mod(int i,int maxi) { return  i;}
uchar i2u_lin(int i,int maxi) { return i*255/maxi;}

void fw_recalc(fractal_window *fw) {
  fw->line=0;
}


void fw_calc_linei(fractal_window *fw,int line) {
  register real cx,cx2,cx3=0,cy,cy2=0,cy3=0;
  unsigned char *p,*q,r,aa=fw->aa,fast=fw->fast,g=0;
  int j,s,w=fw->width;
  p=fw->image+line*w;
  if(fast<2) fast=0;
  else {
    aa=0;
    g=fast-1;
    while(g&&line+g>=fw->height) g--;
  }
  if(fast&&(line%fast)) return;
  cy=((fw->height-1-line)*fw->iy+line*fw->ay)/(fw->height-1);
  if(aa) {
    if(fw->aa==3) {
      j=3*line+1,cy2=((3*fw->height-3-j)*fw->iy+j*fw->ay)/(3*fw->height-3);
      j=3*line+2,cy3=((3*fw->height-3-j)*fw->iy+j*fw->ay)/(3*fw->height-3);
    } else
      j=2*line+1,cy2=((2*fw->height-2-j)*fw->iy+j*fw->ay)/(2*fw->height-2);
  }
  //if(fw->aa) cy2=((2*fw->height-1-2*line-1)*fw->iy+(2*line+1)*fw->ay)/(2*fw->height-1);
  for(j=0;j<fw->width;) {
	cx=((fw->width-1-j)*fw->ix+j*fw->ax)/(fw->width-1);
        s=fw->func(cx,cy);
        //r=fw->f2(fw->func(cx,cy),fw->maxi);
        if(aa) {
         if(aa==3)
	    cx2=((3*fw->width-3-3*j-1)*fw->ix+(3*j+1)*fw->ax)/(3*fw->width-3);
          else
	    cx2=((2*fw->width-2-2*j-1)*fw->ix+(2*j+1)*fw->ax)/(2*fw->width-2);
          s+=fw->func(cx2,cy );
          s+=fw->func(cx ,cy2);
          s+=fw->func(cx2,cy2);
          if(aa==3) {
	    cx3=((3*fw->width-3-3*j-2)*fw->ix+(3*j+2)*fw->ax)/(3*fw->width-3);
            s+=fw->func(cx3,cy );
            s+=fw->func(cx3,cy2);
            s+=fw->func(cx ,cy3);
            s+=fw->func(cx2,cy3);
            s+=fw->func(cx3,cy3);
            s=(s+5)/9;
          } else
            s=(s+2)/4;
        }
        r=255-fw->f2(s,fw->maxi);
	*p++=r;j++;
        if((s=fast)) {
          for(;--s&&j<w;j++) *p++=r;
          for(q=p-fast+w,s=g;s;s--,q+=w)
            memset(q,r,fast);
        }
         
  }
}

DWORD WINAPI fw_calc_thread(LPVOID param) {
  fractal_window *fw=(fractal_window*)param;
  DWORD cth=GetCurrentThreadId();
  for(;;) {
    int line;
    WaitForSingleObject((HANDLE)fw->doit,INFINITE);
    if(fw->thread!=cth) break;
    if((line=fw->line)<fw->height) {
      fw->line++;
      fw_calc_linei(fw,line);
    }
    SetEvent(fw->done);
  }
  ExitThread(0);
  return 0;
}
int fw_calc_line(fractal_window *fw) {
  int line,para;
  if(fw->line>=fw->height) return 0;
  //printf("line %d\n",fw->line);
  line=fw->line++;
  sfw=fw;
  if((para=fw->doit&&fw->line<fw->height)) 
    SetEvent(fw->doit);
  fw_calc_linei(fw,line);
  if(para) WaitForSingleObject(fw->done,INFINITE);
  return fw->line-line;
}


void fw_resize(fractal_window *fw,int width,int height,void *data) {
  fw->width=fw->height=0;
  fw->image=data;
  fw->width=width;
  fw->height=height;
  fw_recalc(fw);
}

void fw_real_window(fractal_window *fw,real ix,real ax,real iy,real ay) {
  fw->ix=ix,fw->ax=ax;
  fw->iy=iy,fw->ay=ay;
}

void fw_move_window(fractal_window *fw,real mx,real my) {
  mx*=fw->ax-fw->ix,my*=fw->ay-fw->iy;
  fw->ix+=mx,fw->iy+=my;
  fw->ax+=mx,fw->ay+=my;
}

void fw_zoom_window(fractal_window *fw,real mul,real div) {
  real cx=(fw->ax+fw->ix)/2,cy=(fw->ay+fw->iy)/2,dx=mul*(fw->ax-fw->ix)/div,dy=mul*(fw->ay-fw->iy)/div;
  fw->ix=cx-dx/2,fw->iy=cy-dy/2;
  fw->ax=cx+dx/2,fw->ay=cy+dy/2;
}

void fw_point_zoom(fractal_window *fw,int x,int y,real mul,real div) {
  double dx=fw->ax-fw->ix,dy=fw->ay-fw->iy,rx=x*dx/fw->width,ry=y*dy/fw->height;
  fw->ix+=rx*(div-mul)/div,fw->iy+=ry*(div-mul)/div;
  fw->ax=fw->ix+dx*mul/div,fw->ay=fw->iy+dy*mul/div;
}

void fw_shift_window(fractal_window *fw,int sx,int sy) {
  real mx=sx*(fw->ax-fw->ix)/fw->width,my=sy*(fw->ay-fw->iy)/fw->height;
  fw->ix+=mx,fw->iy+=my;
  fw->ax+=mx,fw->ay+=my;
}

int bitcount(unsigned x) {
  int bc=0;
  while(x>0) bc+=x&1,x>>=1;
  return bc;
}
void fw_init(fractal_window *fw,int width,int height,void *data) {
  DWORD pam,sam;
  fw->func=ff_mandelbrot;
  fw->f2=i2u_lin;
  fw->line=0;
  fw->image=0;
  fw_real_window(fw,-2,2,-2,2);
  fw->maxi=255;
  fw->p1x=0;
  fw->p1y=0;
  if(GetProcessAffinityMask(GetCurrentProcess(),&pam,&sam)&&bitcount(pam)>1) { 
    HANDLE thread;
    fw->doit=CreateEvent(NULL,FALSE,FALSE,NULL);
    fw->done=CreateEvent(NULL,FALSE,FALSE,NULL);
    thread=CreateThread(NULL,0,fw_calc_thread,fw,0,(DWORD*)&fw->thread);
    CloseHandle(thread);
  } else 
    fw->doit=fw->done=NULL;
  //MessageBox(NULL,fw->doit?"dual core":"single core","paralelism",MB_OK); 
  fw_resize(fw,width,height,data);
}

int fw_done(fractal_window *fw) {
  return fw->line>=fw->height;
}

real fw_x(fractal_window *fw,int x) {
  return fw->ix+x*(fw->ax-fw->ix)/fw->width;
}
real fw_y(fractal_window *fw,int y) {
  return fw->iy+y*(fw->ay-fw->iy)/fw->height;
}

void fw_window(fractal_window *fw,int ix,int iy,int ax,int ay) {
  real nix,niy,nax,nay;
  nix=fw->ix+ix*(fw->ax-fw->ix)/fw->width;
  nax=fw->ix+ax*(fw->ax-fw->ix)/fw->width;
  niy=fw->iy+iy*(fw->ay-fw->iy)/fw->height;
  nay=fw->iy+ay*(fw->ay-fw->iy)/fw->height;
  fw->ix=nix,fw->ax=nax;
  fw->iy=niy,fw->ay=nay;
  fw_recalc(fw);
}

void fw_inc_maxi(fractal_window *fw) {
  fw->maxi*=2;
  fw_recalc(fw);
}

void fw_dec_maxi(fractal_window *fw) {
  if(fw->maxi>1) {
	fw->maxi/=2;
	fw_recalc(fw);
  }
}

void fw_change_i2u(fractal_window *fw) {
  fw->f2=fw->f2==i2u_mod?i2u_lin:i2u_mod;
  fw_recalc(fw);
}

void fw_write_pgm(fractal_window *fw) {
  static int fidx=-1;
  char name[16];
  FILE *f;
  while(1) {
    fidx++;
    sprintf(name,"out%03d.pgm",fidx);
    if((f=fopen(name,"r"))) {
      fclose(f);
      fidx++;
    } else
      if((f=fopen(name,"wb"))) {
        fprintf(f,"P5\n# %f %f %f %f\n",
          (double)(fw->ix),(double)(fw->iy),
          (double)(fw->ax),(double)(fw->ay));
	fprintf(f,"%d %d\n255\n",fw->width,fw->height);
        fwrite(fw->image,fw->width*fw->height,1,f);
	fclose(f);
        return;
      }
  }
}
