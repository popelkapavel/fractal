#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include <windows.h>
#include <winuser.h>
#include "fractald.h"

#include "types.h"
#include "fwindow.h"

#include <string.h>
#include <math.h>

//#define LOG

typedef unsigned char byte;

int grayscale=0;
unsigned char rgb[3]={0,1,2};
int width=640,height=480;
double zoom=1;
double aspect=1;

int depthbit=0,depthbyte=0;
int key_step=10;
double mx=0,my=0,mz=0;
int dirty=1;
byte *backbytes=NULL;
BITMAPINFO *bif=NULL;
byte *bgmem=NULL;
HWND window=NULL;
HINSTANCE hinstance;
HACCEL accel;
fractal_window fw;
HDC dc;
char k_shift,k_ctrl,k_alt;
char f_key;

void repaint() {
  SetDIBitsToDevice(dc,0,0,width,height,0,0,
      0,height,bgmem,bif,DIB_RGB_COLORS);
}

int ff_test(real x,real y) {
  return 255*((2+sin(x+y)+sin(x-y))/4);
}

void update_back() {
  fw_resize(&fw,width,height,backbytes);
}

typedef struct {
  unsigned char i,r,g,b;
} palette_item;

palette_item rainbow_palette[]={
 {0,0,0,0},
 {36,255,0,0},
 {73,255,255,0},
 {109,0,255,0},
 {146,0,255,255},
 {182,0,0,255},
 {219,255,0,255},
 {255,255,255,255},
};

palette_item rgb_palette[]={
 {0,0,0,0},
 {64,255,0,0},
 {128,0,0,255},
 {192,0,255,0},
 {255,255,255,255}
};

palette_item gray_palette[]={
  {0,0,0,0},
  {255,255,255,255}
};

palette_item red_palette[]={ {0,0,0,0}, {255,255,128,128} };
palette_item green_palette[]={ {0,0,0,0}, {255,128,255,128} };
palette_item blue_palette[]={ {0,0,0,0}, {255,128,128,255} };

palette_item yellow_palette[]={ {0,0,0,0}, {255,255,255,0} };
palette_item orange_palette[]={ {0,0,0,0}, {255,255,192,128} };
palette_item cyan_palette[]={ {0,0,0,0}, {255,128,255,255} };


palette_item layer_palette[]={
  {0,0,0,0},
  {36,255,0,0},
  {41,0,0,0},
  {73,255,255,0},
  {78,0,0,0},
  {109,0,255,0},
  {114,0,0,0},
  {146,0,255,255},
  {151,0,0,0},
  {182,0,0,255},
  {187,0,0,0},
  {219,255,0,255},
  {224,0,0,0},
  {255,255,255,255}
};

palette_item bluered_palette[]={
  {0,0,0,0},
  {16,0,0,255},
  {128,255,0,0},
  {255,255,255,255}
};

palette_item greenblue_palette[]={
  {0,0,0,0},
  {16,0,255,0},
  {128,0,0,255},
  {255,255,255,255}
};

palette_item redgreen_palette[]={
  {0,0,0,0},
  {16,255,0,0},
  {128,0,255,0},
  {255,255,255,255}
};


void set_pal(palette_item *p) {
  int i,a,b,d;
  for(i=0;i<256;i++) {
    if(p[1].i<i) p++;
    a=p[1].i-i,b=i-p[0].i,d=p[1].i-p[0].i;
    bif->bmiColors[i].rgbRed=(p[0].r*a+p[1].r*b)/d;
    bif->bmiColors[i].rgbGreen=(p[0].g*a+p[1].g*b)/d;
    bif->bmiColors[i].rgbBlue=(p[0].b*a+p[1].b*b)/d;
  }
}

void inv_pal() {
  int i;
  for(i=0;i<256;i++) {
    bif->bmiColors[i].rgbRed^=255;
    bif->bmiColors[i].rgbGreen^=255;
    bif->bmiColors[i].rgbBlue^=255;
  }
}

void neg_pal() {
  int i;
  for(i=0;i<256;i++) {
    RGBQUAD rgb=bif->bmiColors[i];
    BYTE mi=rgb.rgbBlue,ma=mi,x;
    x=rgb.rgbGreen;if(x>ma) ma=x;else if(x<mi) mi=x;
    x=rgb.rgbRed;if(x>ma) ma=x;else if(x<mi) mi=x;
    rgb.rgbRed=mi+ma-rgb.rgbRed;;
    rgb.rgbGreen=mi+ma-rgb.rgbGreen;
    rgb.rgbBlue=mi+ma-rgb.rgbBlue;
    bif->bmiColors[i]=rgb;
  }
}

void rev_pal() {
  int i;
  RGBQUAD rgb;
  for(i=0;i<128;i++) {
    rgb=bif->bmiColors[i];
    bif->bmiColors[i]=bif->bmiColors[255-i];
    bif->bmiColors[255-i]=rgb;
  }
}

void rotrgb_pal(char right,char swap) {
  int i;
  for(i=0;i<256;i++) {
    RGBQUAD rgb=bif->bmiColors[i];
    BYTE x=rgb.rgbBlue;
    if(swap) {
      rgb.rgbBlue=rgb.rgbRed;
      rgb.rgbRed=x;
    } else if(right) {
      rgb.rgbBlue=rgb.rgbGreen;
      rgb.rgbGreen=rgb.rgbRed;
      rgb.rgbRed=x;
    } else {
      rgb.rgbBlue=rgb.rgbRed;
      rgb.rgbRed=rgb.rgbGreen;
      rgb.rgbGreen=x;
    }
    bif->bmiColors[i]=rgb;
  }
}

void rot_pal(BYTE r) {
  RGBQUAD copy[256];
  memcpy(copy,bif->bmiColors,1024);
  memcpy(bif->bmiColors,copy+r,4*(256-r));
  memcpy(bif->bmiColors+256-r,copy,4*r);
}

void dbl_pal(char mirror) {
  int i;
  for(i=0;i<128;i++) 
    bif->bmiColors[i]=bif->bmiColors[255*i/127];
  for(i=128;i<256;i++) 
    bif->bmiColors[i]=bif->bmiColors[mirror?255-i:i-128];
}

void tri_pal() {
  int i;
  for(i=0;i<86;i++) 
    bif->bmiColors[i]=bif->bmiColors[255*i/85];
  for(i=0;i<86;i++) 
    bif->bmiColors[169-i]=bif->bmiColors[170+i]=bif->bmiColors[i];
}

int resize_dc() {
  RECT r;
  int nwidth,nheight;

  GetClientRect(window,&r);
  nwidth=r.right,nheight=r.bottom;
  nwidth=(nwidth+3)&~3;
  if(width==nwidth&&height==nheight&&bif)
    return 0;
  width=nwidth,height=nheight;
  if(!bif) { 
    bif=malloc(sizeof(BITMAPINFOHEADER)+sizeof(RGBQUAD[256]));
    memset(bif,0,sizeof(BITMAPINFOHEADER));
    set_pal(gray_palette);
    //for(i=0;i<256;i++)
    //  bif->bmiColors[i].rgbBlue=bif->bmiColors[i].rgbRed=bif->bmiColors[i].rgbGreen=i;
    bif->bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    bif->bmiHeader.biPlanes=1;
    bif->bmiHeader.biBitCount=8;
    bif->bmiHeader.biCompression=BI_RGB;
    bif->bmiHeader.biXPelsPerMeter=1000;
    bif->bmiHeader.biYPelsPerMeter=1000;
    bif->bmiHeader.biClrUsed=256;
    bif->bmiHeader.biClrImportant=256;
  }
  if(backbytes)
    free(backbytes);
  backbytes=(byte*)malloc(width*height);
  bif->bmiHeader.biWidth=width;
  bif->bmiHeader.biHeight=-height;
  bif->bmiHeader.biSizeImage=width*height;
  bgmem=backbytes;
  return 1;
}

long FAR PASCAL main_WndProc (HWND hWnd, UINT iMessage,
    WPARAM wParam, LPARAM lParam);

void create_window(char full) {
  WNDCLASS WndClass;
  DWORD ws;

  accel = LoadAccelerators(hinstance,"accel_main");

  WndClass.cbClsExtra = 0;
  WndClass.cbWndExtra = 0;
  WndClass.hbrBackground = NULL;
  WndClass.hCursor=LoadCursor(NULL, IDC_ARROW);
  WndClass.hIcon=LoadIcon(hinstance,"icon_fractal");
  WndClass.hInstance = hinstance;
  WndClass.style=CS_OWNDC; // CS_HREDRAW | CS_VREDRAW;
  WndClass.lpfnWndProc = main_WndProc;
  WndClass.lpszClassName = "FractalClass";
  WndClass.lpszMenuName = NULL ; //"menu_main";
  RegisterClass(&WndClass); // main window class

  ws=WS_VISIBLE|WS_TILEDWINDOW;
  window=CreateWindow("FractalClass","Fractal",ws,
      0,0,width,height,NULL,NULL,hinstance,NULL);
  if(full) {
    ShowWindow(window,SW_MAXIMIZE);
    SetWindowLong(window,GWL_STYLE,GetWindowLong(window,GWL_STYLE)^WS_CAPTION);
    SetMenu(window,NULL);
  }
  dc=GetDC(window);
  resize_dc();
}

void write_bmp(char *filename) {
  FILE *f; 
  BITMAPFILEHEADER bfh;
  unsigned char *image;
  int bif_size,w,h,si;

  if(!(f=fopen(filename,"wb")))
    return;
  bif_size=sizeof(BITMAPINFOHEADER)+256*sizeof(RGBQUAD);
  memset(&bfh,0,sizeof(bfh));
  bfh.bfType='B'|('M'<<8);
  bfh.bfOffBits=sizeof(bfh)+bif_size;
  bfh.bfSize=bfh.bfOffBits+fw.width*fw.height;
  fwrite(&bfh,1,sizeof(bfh),f);
  w=bif->bmiHeader.biWidth;
  h=bif->bmiHeader.biHeight;
  si=bif->bmiHeader.biSizeImage;
  bif->bmiHeader.biWidth=fw.width;
  bif->bmiHeader.biHeight=fw.height;
  bif->bmiHeader.biSizeImage=fw.width*fw.height;
  fwrite(bif,1,bif_size,f);
  bif->bmiHeader.biWidth=w;
  bif->bmiHeader.biHeight=h;
  bif->bmiHeader.biSizeImage=si;
  for(image=fw.image+fw.height*fw.width;image>fw.image;) {
    image-=fw.width;
    fwrite(image,1,fw.width,f);
  }
  fclose(f);
}

void write_bmpidx(const char *mask) {
  static int fidx=-1;
  char name[32];
  FILE *f;
  while(1) {
    fidx++;
    sprintf(name,mask,fidx);
    if((f=fopen(name,"r"))) {
      fclose(f);
      fidx++;
    } else {
      write_bmp(name);
      break;
    }
  }
}

int fn_ext(char *filename,int extlen,char *extension) {
  char *h,*e;
  for(h=filename,e=NULL;*h;h++) 
    switch(*h) {
     case '/':
     case '\\':
     case ':':e=NULL;break;
     case '.':e=h;break;
    }
  h=extension;
  if(e++) {
    while(--extlen&&*e)
      *h++=tolower(*e++);
  }
  *h=0;
  return !!*extension;
}

int GetSaveFilename(char *file,char *title,char *filter) {
  char filename[256],dir[256];
  OPENFILENAME of;
  int r;

  memset(&of,0,sizeof(of));
  of.lStructSize=sizeof(of);
  //of.hwndOwner=esktopWindow();
  of.Flags=OFN_LONGNAMES|OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY;

  filename[0]=0;
  of.lpstrTitle=title;
  of.lpstrFilter=filter;
  GetCurrentDirectory(sizeof(dir),dir);
  of.lpstrInitialDir=dir;
  of.lpstrFile=filename;
  of.nMaxFile=sizeof(filename);

  if((r=GetSaveFileName(&of))) {
    char ext[8];
    strcpy(file,filename);
    if(!fn_ext(filename,sizeof(ext),ext)&&of.nFilterIndex) {
      char *h,*h2;
      int n;
      
      for(h=filter,n=2*of.nFilterIndex-1;n;n--) {
        while(*h) h++;
        h++;
      }
      if(h[0]=='*'&&h[1]=='.'&&h[2]&&h[2]!='*') {
        h+=1;
        h2=file+strlen(file);
        while(*h&&*h!=',') *h2++=*h++;
        *h2=0;
      }
    }
  }
  return r;
}

void PrintHelp(HWND wnd) {
  MessageBox(wnd,
"F1:  this help\n"
"Esc,q: exit\n"
"F11: full screen (or space, ctrl hides/shows menu)\n"
"m:   menu on/off\n"
"arrow: move by pixels\n"
"PgUp: move by page (PgDown,Delete,End)\n"
"Ins: zoom in (or Enter,Home/Backspace zoom out)\n"
"\n"
"r:   reset zoom (shift,ctrl also set mandelbrot set)\n"
"j:   julia (shift juliab, ctrl mandelbrot)\n"
"h:   julia 3 (...) \n"
"k:   julia 4 (...) \n"
"n:   julia 16 (...) \n"
"b:   julia 64 (...) \n"
"\n"
"1-9: color and palletes\n"
"~:   rotate rgb (shift reverse palette,ctrl rgb<=>cmy),ctrl+shift invert\n"
"i:   invert colors,(shift reverse palette)\n"
"d:   double palette (shift with mirror,ctrl triple)\n"
"t:   palette modulo on/off\n"
"[]:  rotate palette (shift 4x,ctrl 8x)\n"
".,:  decrease/increase depth calculation\n"
"a:   2x2 antialias on/off (Ctrl for 3x3)\n"
"s:   4x4 speedup on/off (ctrl for 8x8 nad shift for 16x16)\n"
"\n"
"p:   write out.pgm file\n"
"f:   save bmp file with dialog\n"
"\n"
"Command line:\n"
"-f fullscreen\n"
"-a antialias 2x2 (-aa 3x3)\n"
"-s speedup 4x4 (-ss 8x8,-sss 16x16)\n"
    ,"Fracatal 0.12",MB_OK
  );
}

void Wheel(int wheel,int x,int y,char ctrl,char shift) {
  if(ctrl&&!shift) 
    fw_move_window(&fw,0,wheel>0?-0.125:0.125);
  else if(shift&&!ctrl) 
    fw_move_window(&fw,wheel>0?-0.125:0.125,0);
  else 
    fw_point_zoom(&fw,x,y,wheel>0?ctrl?0.9375:0.75:ctrl?1.0625:1.25,1);
  fw_recalc(&fw);
}

fractal_function f_function(int key,char ctrl,char shift) {
  fractal_function ff;
  switch(key) {
   case 'B':ff=ctrl?ff_mandel64:shift?ff_julia64b:ff_julia64;break;
   case 'N':ff=ctrl?ff_mandel16:shift?ff_julia16b:ff_julia16;break;
   case 'K':ff=ctrl?ff_mandel4:shift?ff_julia4b:ff_julia4;break;
   case 'H':ff=ctrl?ff_mandel3:shift?ff_julia3b:ff_julia3;break;
   case 'L':ff=ctrl?ff_mandel6:shift?ff_julia6b:ff_julia6;break;
   default:ff=ctrl?ff_mandelbrot:shift?ff_juliab:ff_julia;break;
  }
  return ff;
}


int ProcessKey(int Key,int x,int y) {
  int r=0;
  fractal_function ff;
  real p1x,p1y;
  switch(Key) {
   case 192:k_ctrl?k_shift?inv_pal():neg_pal():k_shift?rev_pal():rotrgb_pal(1,k_alt);goto repaint;
   case 219:rot_pal(k_ctrl?8:k_shift?4:1);goto repaint;
   case 221:rot_pal(k_ctrl?-8:k_shift?-4:-1);goto repaint;
   case '1':set_pal(gray_palette);goto repaint;
   case '2':set_pal(red_palette);goto repaint;
   case '3':set_pal(yellow_palette);goto repaint;
   case '4':set_pal(orange_palette);goto repaint;
   case '5':set_pal(rainbow_palette);goto repaint;
   case '6':set_pal(layer_palette);goto repaint;
   case '7':set_pal(bluered_palette);goto repaint;
   case '8':set_pal(greenblue_palette);goto repaint;
   case '9':set_pal(redgreen_palette);goto repaint;
   case 'D':
    if(k_ctrl) tri_pal();
    else dbl_pal(k_shift);
    goto repaint;
   case 'A':if(k_ctrl&&fw.aa==3&&!fw.fast) break;fw.aa=k_ctrl?3:fw.aa&&!fw.fast?0:2;if(fw.aa) fw.fast=0;goto recalc;
   case 'S':
     if((k_ctrl&&fw.fast==8)||(k_shift&&fw.fast==16)) break;
     fw.fast=k_ctrl?8:k_shift?16:fw.fast?0:4;goto recalc;
   case 'I':
    (k_ctrl?neg_pal:k_shift?inv_pal:rev_pal)();
   repaint:
    repaint();
    break;
   case 'T':
    fw_change_i2u(&fw);
    goto recalc;
   case 'R':
    if(k_shift||k_ctrl) fw.func=f_function(f_key,1,0);
    fw_real_window(&fw,-2,-2,2,2);
    goto recalc;
   case 188:fw_dec_maxi(&fw);goto recalc;
   case 190:fw_inc_maxi(&fw);goto recalc;
   case VK_PRIOR:fw_move_window(&fw,0,k_ctrl?-0.25:k_shift?-0.5:-1);goto recalc;
   case VK_NEXT:fw_move_window(&fw,0,k_ctrl?+0.25:k_shift?+0.5:+1);goto recalc;
   case VK_DELETE:fw_move_window(&fw,k_ctrl?-0.25:k_shift?-0.5:-1,0);goto recalc;
   case VK_END:fw_move_window(&fw,k_ctrl?+0.25:k_shift?+0.5:+1,0);goto recalc;
   case VK_RETURN:
   case VK_INSERT:fw_zoom_window(&fw,k_ctrl?k_shift?0.9375:0.875:k_shift?0.75:0.5,1);goto recalc;
   case VK_BACK:
   case VK_HOME:fw_zoom_window(&fw,k_ctrl?k_shift?1.0625:8:k_shift?4:2,1);goto recalc;
   case VK_LEFT:fw_shift_window(&fw,k_ctrl?-100:k_alt?-1:-10,0);goto recalc;
   case VK_RIGHT:fw_shift_window(&fw,k_ctrl?+100:k_alt?+1:+10,0);goto recalc;
   case VK_UP:fw_shift_window(&fw,0,k_ctrl?-100:k_alt?-1:-10);goto recalc;
   case VK_DOWN:fw_shift_window(&fw,0,k_ctrl?+100:k_alt?+1:+10);goto recalc;
   case VK_F1:PrintHelp(window);break;
   case ' ':
   case VK_F11:{
     WINDOWPLACEMENT wp;
     char max;
     wp.length=sizeof(wp);
     GetWindowPlacement(window,&wp);
     max=wp.showCmd!=SW_MAXIMIZE;
     ShowWindow(window,max?SW_MAXIMIZE:SW_RESTORE);
     if(k_ctrl) {
       LONG ws=GetWindowLong(window,GWL_STYLE);
       if(max) ws&=~WS_CAPTION;else ws|=WS_CAPTION;
       SetWindowLong(window,GWL_STYLE,ws);
       SetMenu(window,NULL);
     }
    } break;
   case 'M':
    SetWindowLong(window,GWL_STYLE,GetWindowLong(window,GWL_STYLE)^WS_CAPTION);
    SetMenu(window,NULL);
    goto recalc;
   case VK_ESCAPE:
   case 'Q':
    PostQuitMessage(0);
    break;
   case 'B':f_key=Key;
    ff=k_ctrl?ff_mandel64:k_shift?ff_julia64b:ff_julia64;
    goto setpt;
   case 'N':f_key=Key;
    ff=k_ctrl?ff_mandel16:k_shift?ff_julia16b:ff_julia16;
    goto setpt;
   case 'K':f_key=Key;
    ff=k_ctrl?ff_mandel4:k_shift?ff_julia4b:ff_julia4;
    //fw.func=k_shift?ff_julia16:ff_julia4;
    goto setpt;
   case 'H':f_key=Key;
    ff=k_ctrl?ff_mandel3:k_shift?ff_julia3b:ff_julia3;
    goto setpt;
   case 'L':f_key=Key;
    ff=k_ctrl?ff_mandel6:k_shift?ff_julia6b:ff_julia6;
    goto setpt;
   case 'J':f_key=Key;
    ff=k_ctrl?ff_mandelbrot:k_shift?ff_juliab:ff_julia;
   setpt:
    p1x=fw_x(&fw,x),p1y=fw_y(&fw,y);
    if(fw.func==ff&&p1x==fw.p1x&&p1y==fw.p1y) break;
    fw.func=ff;
    fw.p1x=p1x,fw.p1y=p1y;
#if LOG
    { FILE *f=fopen("out.log","a"); 
      fprintf(f,"%d,%d %f,%f %f,%f,%f,%f\n",x,y,(double)fw.p1x,(double)fw.p1y,(double)fw.ix,(double)fw.iy,(double)fw.ax,(double)fw.ay);
      fclose(f);
    }
#endif
   recalc:
    fw_recalc(&fw);
    r=1;
    break;
   case 'P':
    fw_write_pgm(&fw);
    break;
/*   case 'Z':
    { char buf[256];
      sprintf(buf,"%d %d %d\n"
        ,(int)&((fractal_window*)0)->p1x,(int)&((fractal_window*)0)->p1y,(int)&((fractal_window*)0)->maxi);
      MessageBox(NULL,buf,"Y",MB_OK);
    } break; */
   case 'F': {
      static char filename[256]="out.bmp";
      int scale=0;
      void *image=NULL;

      if(GetSaveFilename(filename,"Save","Windows Bitmap (*.bmp)\0*.bmp\0All files (*.*)\0*.*\0")) {
        if(k_shift||k_ctrl) {
          scale=k_ctrl?(k_shift?8:4):2;
          image=fw.image;
          fw_resize(&fw,fw.width*scale,fw.height*scale,malloc(fw.width*scale*fw.height*scale));
          while(fw_calc_line(&fw));
        }
        write_bmp(filename);
        if(k_shift||k_ctrl) {
          free(fw.image);
          fw_resize(&fw,fw.width/scale,fw.height/scale,image);
        }
      }
    //write_bmpidx("out%03d.bmp");
    } 
    break;
   default:; /* {
      char buf[64];
      sprintf(buf,"Key:%c [%d:0x%x] %d.%d",Key,Key,Key,x,y);
      MessageBox(NULL,buf,"key",MB_OK); 
    } */
  }
  return r;
}


void ProcessCommand(int Command) {
  switch(Command) {
   case UM_ResetWindow:
    fw_real_window(&fw,-2,-2,2,2);
    goto update;
   case UM_SwapTitle:
    SetWindowLong(window,GWL_STYLE,GetWindowLong(window,GWL_STYLE)^WS_CAPTION);
    SetMenu(window,NULL);
    //PostMessage(window,WM_SIZE,0,0);
    //resize_dc();
    goto update;
   default:break;
   update:
    dirty=1;//update_back();
  }; 
}

void XorBox(HDC dc,int x1,int y1,int x2,int y2) {
  int rop;
  HGDIOBJ pen;

  rop=SetROP2(dc,R2_XORPEN);
  pen=SelectObject(dc,GetStockObject(WHITE_PEN)); 
  MoveToEx(dc,x1,y1,NULL);
  LineTo(dc,x2,y1);
  LineTo(dc,x2,y2);
  LineTo(dc,x1,y2);
  LineTo(dc,x1,y1);
  SelectObject(dc,pen);
  SetROP2(dc,rop);
}

long FAR PASCAL main_WndProc (HWND hWnd, UINT iMessage,
    WPARAM wParam, LPARAM lParam) {
  static int px,py; // mouse left button press x,y
  static int lx,ly,lb; // last mouse position
  int mx,my; // actual mouse x,y

  LRESULT r=0;

  switch(iMessage)  {
   case WM_PAINT:
    if(bgmem) {
      PAINTSTRUCT PS;
      BeginPaint(hWnd,&PS);
      repaint();
      EndPaint(hWnd,&PS);
    } break;
//   case WM_SYSKEYDOWN:
   case WM_KEYDOWN: { 
      MSG m={window,iMessage,wParam,lParam};
      if(!TranslateAccelerator(window,accel,&m)) {
        switch(wParam) {
         case ' ':break;
         case 'M':break;
         case VK_TAB:
          if(lb) {
            POINT pt;
            XorBox(dc,px,py,lx,ly);
            GetCursorPos(&pt);
            mx=px,my=py;
            px=lx,py=ly;
            lx=mx,ly=my;
            SetCursorPos(pt.x+lx-px,pt.y+ly-py);
            XorBox(dc,px,py,lx,ly);
          }
          break;
        }
      }
    } break;
   case WM_COMMAND:
    ProcessCommand(LOWORD(wParam));
    break;
   case WM_SIZE:
    if(window&&wParam!=SIZE_MINIMIZED) {
      if(resize_dc())
        dirty=1;//update_back();
    }
    break;
   case WM_DESTROY:
    PostQuitMessage(0);
    break;
   case WM_LBUTTONDOWN:
    px=(short)LOWORD(lParam),py=(short)HIWORD(lParam);
    SetCapture(hWnd);
    XorBox(dc,px,py,px,py);
    lx=px,ly=py,lb=1;
    break;
   case WM_RBUTTONDOWN:
    px=LOWORD(lParam),py=HIWORD(lParam);
    SetCapture(hWnd);
    break;
   case WM_MOUSEMOVE:
    mx=(short)LOWORD(lParam),my=(short)HIWORD(lParam);
    if(wParam&MK_LBUTTON) {
      XorBox(dc,px,py,lx,ly);
      XorBox(dc,px,py,mx,my);
      //dirty=1;//update_back();
    } 
    lx=mx,ly=my;
    break;
   case WM_LBUTTONUP:
    lb=0;
    XorBox(dc,px,py,lx,ly);
    mx=(short)LOWORD(lParam),my=(short)HIWORD(lParam);
    if(abs((mx-px)*(my-py))<1024) { // pixel
      fw_window(&fw,lx-fw.width/4,ly-fw.height/4,lx+fw.width/4,ly+fw.height/4);
    } else { // window
      real r,ix,ax,iy,ay,w,h,w2,h2;

      ix=fw_x(&fw,px),ax=fw_x(&fw,mx);
      if(ix>ax) r=ix,ix=ax,ax=r;
      iy=fw_y(&fw,py),ay=fw_y(&fw,my);
      if(iy>ay) r=iy,iy=ay,ay=r;
      w=ax-ix,h=ay-iy;
      w2=h*width/height,h2=w*height/width;
      if(w2>w) w2=(w2-w)/2,ix-=w2,ax+=w2;
      else h2=(h2-h)/2,iy-=h2,ay+=h2;
      fw_real_window(&fw,ix,iy,ax,ay);
    }
    ReleaseCapture();
    fw_recalc(&fw);
    break;
   case WM_RBUTTONUP:
    mx=(short)LOWORD(lParam),my=(short)HIWORD(lParam);
    if(abs((mx-px)*(my-py))<8) { // pixel
      fw_zoom_window(&fw,2,1);
      //fw_window(&fw,px-fw.width,py-fw.height,px+fw.width,py+fw.height);
    } else {
      px-=mx,py-=my;
      fw_window(&fw,px,py,px+fw.width,py+fw.height);
    }
    fw_recalc(&fw);
   default: {
    r=DefWindowProc(hWnd, iMessage, wParam, lParam);
   } break;
  }
  return r;
}

char Alt() { return 0!=(GetKeyState(VK_MENU)&0x8000);}

int loop() {
  MSG m;
  int lines;

  while(WaitMessage()) {
   peek:
    while(PeekMessage(&m,NULL,0,0,PM_REMOVE)) {
      if(m.message==WM_QUIT)
        return m.wParam;
      if(m.message==WM_KEYDOWN||m.message==WM_SYSKEYDOWN) {
        if(m.wParam==VK_SHIFT) k_shift=1;
        if(m.wParam==VK_CONTROL) k_ctrl=1;
        if(m.wParam==VK_MENU) k_alt=1;
        if(ProcessKey((int)m.wParam,m.pt.x,m.pt.y))
          continue;
      }
      if(m.message==WM_KEYUP||m.message==WM_SYSKEYUP) {
        if(m.wParam==VK_SHIFT) k_shift=0;
        if(m.wParam==VK_CONTROL) k_ctrl=0;
        if(m.wParam==VK_MENU) k_alt=0;
      }
      if(m.message==WM_MOUSEWHEEL) {
         short wh=m.wParam>>16;
         POINT pt=m.pt;
         ScreenToClient(window,&pt);
         if(wh) Wheel(wh,m.pt.x,m.pt.y,m.wParam&0x8,m.wParam&0x4);
         continue;
      }
      TranslateMessage(&m);
      DispatchMessage(&m);
    }
    if(dirty) {
      update_back();
      dirty=0;
    }
    if((lines=fw_calc_line(&fw))) {
      SetDIBitsToDevice(dc,0,fw.line-lines,width,lines,0,height-fw.line,
        0,height,bgmem,bif,DIB_RGB_COLORS);
      goto peek;
    }
  }
  return 0;
}

char IsWhite(char ch) { return ch==' '||ch=='\t'; }

int PASCAL WinMain(HINSTANCE hCurInstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int nCmdShow) {
  int r;
  char *h,fullscr=0,aa=0,fast=0;
  
  /*{ char buffer[64];
    sprintf(buffer,"%d\n",(char*)&fw.p1y-(char*)&fw);
    MessageBox(NULL,buffer,"title",MB_OK);
  }*/
  for(h=lpCmdLine;*h;) {
    while(IsWhite(*h)) h++;
    if(*h=='-') {
      for(h++;*h&&!IsWhite(*h);h++) 
        switch(*h) {
         case 'f':fullscr=1;break;
         case 'a':aa=aa?3:2;break;
         case 's':fast=fast==8?16:fast?8:4;break;
         case 'h':PrintHelp(NULL);break;
        }
    } else while(*h&&!IsWhite(*h)) h++; 
  }
  hinstance=hCurInstance;
  create_window(fullscr);
  fw_init(&fw,1,1,NULL);
  fw.aa=aa;fw.fast=fast;
  update_back();
  r=loop();

  return r;
}

